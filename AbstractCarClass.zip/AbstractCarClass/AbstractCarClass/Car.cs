﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractCarClass
{
    internal abstract class Car
    {
        public abstract void move();
    }
}
